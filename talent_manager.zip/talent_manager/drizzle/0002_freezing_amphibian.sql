ALTER TABLE `projects` MODIFY COLUMN `talents` json;--> statement-breakpoint
ALTER TABLE `talents` MODIFY COLUMN `photos` json;--> statement-breakpoint
ALTER TABLE `talents` MODIFY COLUMN `phoneNumbers` json;--> statement-breakpoint
ALTER TABLE `talents` MODIFY COLUMN `socialMedia` json;--> statement-breakpoint
ALTER TABLE `talents` MODIFY COLUMN `tags` json;